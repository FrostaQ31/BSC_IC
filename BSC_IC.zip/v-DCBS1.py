# -*- coding: UTF-8 -*-

import os
import time
import random
import numpy as np
import argparse
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter
import layers
import models
import math
import datasets
import utils
import metrics
import visualization
from itertools import chain
import torchvision
import torchvision.models as md
from gcc.utils.aug_feat import AugFeat
from gcc.utils.config import create_config
from gcc.utils.common_config import get_criterion, get_model, get_train_dataset,\
                                get_val_dataset, get_train_dataloader,\
                                get_val_dataloader, get_train_transformations,\
                                get_val_transformations, get_optimizer,\
                                adjust_learning_rate
import faiss
from termcolor import colored
from torch.cuda.amp import autocast, GradScaler
from gcc.utils.utils import fill_memory_bank, fill_memory_bank_mean
from gcc.utils.memory import MemoryBank
from gcc.utils.evaluate_utils import contrastive_evaluate, get_predictions, hungarian_evaluate
def _main():

    org_feat_memory = AugFeat('./org_feat_memory', 4)
    aug_feat_memory = AugFeat('./aug_feat_memory', 4)

    parser = argparse.ArgumentParser()
    parser.add_argument('--config_env', default='gcc/configs/env.yml',
                        help='Config file for the environment')

    parser.add_argument('--config_exp', default='gcc/configs/end2end/end2end_stl10.yml',
                        help='Config file for the experiment')

    parser.add_argument('--dataset-type', type=str, default='FashionMNIST',
                        choices=['MNIST', 'FashionMNIST', 'CIFAR10', 'STL10', 'ImageNet10', 'TinyImageNet','CIFAR-100'],
                        help='type of the dataset')

    parser.add_argument('--dataset-path', type=str, default='./datasets', help='path to the dataset')

    parser.add_argument('--img-type', type=str, default='grayscale', choices=['rgb', 'grayscale', 'sobel'],
                        help='type of the image')

    parser.add_argument('--dim-zs', type=int, default = 0, help='dimension of zs')
    parser.add_argument('--dim-zc', type=int, default = 10, help='dimension of zc')
    parser.add_argument('--zs-std', type=float, default = 0.1,
                        help='standard deviation of the prior gaussian distribution for zs')

    parser.add_argument('--beta-mi', type=float, default=0, help='beta mi')
    parser.add_argument('--beta-adv', type=float, default=1., help='beta adv')
    parser.add_argument('--beta-aug', type=float, default=1, help='beta aug')

    parser.add_argument('--lambda-gp', type=float, default=10.0, help='gradient penalty coefficient')
    parser.add_argument('--skip-iter', type=int, default=1,
                        help='the number of critic iterations per encoder iteration')

    parser.add_argument('--batch-size', type=int, default=64, help='batch size')
    parser.add_argument('--lr', type=float, default=0.0001, help='learning rate')
    parser.add_argument('--epochs', type=int, default=3000,
                        help='number of epochs, note that you can early stop when the critic loss converges')

    parser.add_argument('--seed', type=int, default=111, help='random seed')
    parser.add_argument('--num-workers', type=int, default=8, help='number of workers for the dataloaders')
    parser.add_argument('--checkpoint-root', type=str, default='./checkpoint', help='path to the checkpoint root')
    parser.add_argument('--save-per-epochs', type=int, default=50, help='save the models per number of epochs')
    parser.add_argument('--model-name', type=str, default='DCCS', help='name of the model')
    parser.add_argument(
        "--resnet_version", default="resnet32", type=str, help="ResNet version."
    )
    parser.add_argument("--image-size", default=32, type=int, help="Image size")
    args = parser.parse_args()
    topk = 3
    import ssl
    ssl._create_default_https_context = ssl._create_unverified_context

    p = create_config(args.config_env, args.config_exp)
    # create checkpoint directory
    # checkpoint_root/dataset_type/model_name/
    checkpoint_path = os.path.join(args.checkpoint_root, args.dataset_type, args.model_name)

    os.makedirs(checkpoint_path, exist_ok=True)
    # directory to save models
    os.makedirs(os.path.join(checkpoint_path, 'model'), exist_ok=True)
    # directory to save images
    os.makedirs(os.path.join(checkpoint_path, 'img'), exist_ok=True)

    # create logger
    console_logger, file_logger = utils.create_logger(os.path.join(checkpoint_path, 'train.log'))

    file_logger.info('Args: %s' % str(args))
    file_logger.info('Checkpoint path: %s' % checkpoint_path)

    # set seed
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    # create datasets
    train_dataset = datasets.ClusterDataset(args.dataset_path, args.dataset_type, args.img_type, training=True)
    eval_dataset = datasets.ClusterDataset(args.dataset_path, args.dataset_type, args.img_type, training=False)
    eval_dataset224 = datasets.ClusterDataset(args.dataset_path, args.dataset_type, args.img_type, training=False)



    file_logger.info('Number of training samples: %d' % len(train_dataset))
    file_logger.info('Number of evaluating samples: %d' % len(eval_dataset))

    file_logger.info('Transforms for the images: %s' % str(train_dataset.transforms))
    file_logger.info('Transforms for the augmented images: %s' % str(train_dataset.transforms_aug))

    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers,
                              pin_memory=True, drop_last=True)
    eval_loader = DataLoader(eval_dataset, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers,
                             pin_memory=True, drop_last=False)

    # # Memory Bank
    # print(colored('Build MemoryBank', 'blue'))
    # base_dataset = get_train_dataset(p, val_transforms, to_end2end_dataset=True, split='train') # Dataset for performance test
    # base_dataloader = get_val_dataloader(p, base_dataset)
    # memory_bank_base = MemoryBank(len(base_dataset),
    #                             10,
    #                             p['num_classes'], p['criterion_kwargs']['temperature'])
    # memory_bank_base.cuda()
    # memory_bank_val = MemoryBank(len(val_dataset),
    #                             10,
    #                             p['num_classes'], p['criterion_kwargs']['temperature'])
    # memory_bank_val.cuda()

    encoder = models.get_encoder(args.dataset_type, args.img_type, args.dim_zs, args.dim_zc,online=True)
    encoder1 = models.get_encoder(args.dataset_type, args.img_type, args.dim_zs, args.dim_zc,online=False)
    print(encoder)
    print(encoder1)


    critic = models.get_critic(args.dim_zs, args.dim_zc)

    sobel = layers.SobelLayer(normalize=True)

    w_batch = torch.tensor([60000,topk])
    # get device
    if torch.cuda.is_available():
        device = torch.device('cuda:0')
        num_gpus = torch.cuda.device_count()
        if num_gpus > 1:
            encoder = nn.DataParallel(encoder)
            encoder1 = nn.DataParallel(encoder1)
            critic = nn.DataParallel(critic)
            sobel = nn.DataParallel(sobel)
        file_logger.info('Using %d GPU' % num_gpus)
    else:
        device = torch.device('cpu')
        file_logger.info('Using CPU')
    encoder.to(device)
    encoder1.to(device)
    critic.to(device)
    sobel.to(device)
    optimizer_e = optim.Adam(encoder.parameters(), lr=0.0003, betas=(0.5, 0.9))
    optimizer_c = optim.Adam(critic.parameters(), lr=0.0001, betas=(0.5, 0.9))
    model_fp = os.path.join("checkpoints\FashionMNIST10\end2end\checkpoint.pth.tar")
    # create SummaryWriter
    writer = SummaryWriter(comment='_' + '_'.join([args.dataset_type, args.model_name]))
    print(model_fp)
    if os.path.exists(model_fp):
        print(colored('Restart from checkpoint {}'.format(model_fp), 'blue'))
        checkpoint = torch.load(model_fp)
        optimizer_e.load_state_dict(checkpoint['optimizer_e'])
        optimizer_c.load_state_dict(checkpoint['optimizer_c'])
        encoder.load_state_dict(checkpoint['model'])
        encoder1.load_state_dict(checkpoint['model1'])
        critic.load_state_dict(checkpoint['critic'])
        encoder.cuda()
        critic.cuda()
        start_epoch = 0  # 10000 for evaluate directly
    else:
        print(colored('No checkpoint file at {}'.format(model_fp), 'blue'))
        start_epoch = 0
        encoder.cuda()
        encoder1.cuda()
        critic.cuda()
    global_step = 0
    best_acc = 0.0
    best_ari = 0.0
    best_nmi = 0.0
    best_metrics = best_acc , best_ari , best_nmi
    for epoch in range(start_epoch, args.epochs):
        # train
        # global_step = train_epoch(train_loader, encoder,encoder1, critic, sobel, device,w_batch,
        #                       optimizer_e, optimizer_c, epoch, aug_feat_memory, org_feat_memory, p['log_output_file'],
        #                           global_step, file_logger, writer, args, True)

        if epoch >= 0 and epoch % 1 == 0:
            print ("Start to evaluate...")
            max_acc, max_nmi, max_ari = eval_epoch(eval_loader, encoder, critic, sobel,
                                                   device, epoch, checkpoint_path, file_logger, writer,best_metrics,args)
            #
            # predictions = get_predictions(p, eval_loader, encoder)
            # lowest_loss_head = 0
            # clustering_stats = hungarian_evaluate(lowest_loss_head, predictions, compute_confusion_matrix=False)
            # print(clustering_stats, len(eval_loader))
            # with open (p['log_output_file'], 'a+') as fw:
            #     fw.write(str(clustering_stats) + "\n")

            if max_acc > best_acc:
                best_acc = max_acc
                print ('Best acc: ', best_acc)
                print('Checkpoint ...')
                torch.save({'optimizer_e': optimizer_e.state_dict(), 'optimizer_c': optimizer_c.state_dict(),
                            'model': encoder.state_dict(),'model1': encoder1.state_dict(),'critic': critic.state_dict(),
                            'epoch': epoch + 1}, model_fp)

    writer.close()
class EMA:
    def __init__(self, beta):
        super().__init__()
        self.beta = beta

    def update_average(self, old, new):
        if old is None:
            return new
        return old * self.beta + (1 - self.beta) * new


def update_moving_average(ema_updater, ma_model, current_model):
    for current_params, ma_params in zip(
        current_model.parameters(), ma_model.parameters()
    ):
        old_weight, up_weight = ma_params.data, current_params.data
        ma_params.data = ema_updater.update_average(old_weight, up_weight)

def en_loss(c_i):
    p_i = c_i.sum(0).view(-1)
    p_i /= p_i.sum()
    ne_i = math.log(p_i.size(0)) + (p_i * torch.log(p_i)).sum()
    ne_loss = ne_i
    return ne_loss

def loss_fn(x, y):
    x = F.normalize(x, dim=-1, p=2)
    y = F.normalize(y, dim=-1, p=2)
    return 2 - 2 * (x * y).sum(dim=-1)

def off_diagonal(x):
    # return a flattened view of the off-diagonal elements of a square matrix
    n, m = x.shape
    assert n == m
    return x.flatten()[:-1].view(n - 1, n + 1)[:, 1:].flatten()

def train_epoch(train_loader, encoder,encoder1, critic, sobel, device,w, optimizer_e, optimizer_c, epoch,
                aug_feat_memory, org_feat_memory, log_output_file,
                global_step, file_logger, writer, args, only_train_pretext=True):
    train_data_time = utils.AverageMeter()
    train_batch_time = utils.AverageMeter()
    train_mi_loss = utils.AverageMeter()
    train_aug_loss = utils.AverageMeter()
    train_adv_e_loss = utils.AverageMeter()
    train_adv_c_loss = utils.AverageMeter()
    scaler = GradScaler()
    mse_loss = nn.MSELoss()
    # criterion = nn.CrossEntropyLoss(reduction="sum")
    # similarity_f = nn.CosineSimilarity(dim=2)
    kl_div_loss = nn.KLDivLoss(reduction='batchmean')
    encoder.train()
    encoder1.train()
    target_ema_updater = EMA(0.99)
    critic.train()

    tic = time.time()
    tic1 = time.time()

    for i, data in enumerate(train_loader):
        optimizer_e.zero_grad()
        train_data_time.update(time.time() - tic)
        x, x_aug = data
        x = x.to(device, non_blocking=True)
        x_aug = x_aug.to(device, non_blocking=True)
        b = x.size(0)
        if global_step % (args.skip_iter + 1) == args.skip_iter:
            with autocast():
                zc_aug_logit = encoder(x_aug)
                zc_logit = encoder(x)

                zc = F.softmax(zc_logit, dim=1)
                zc_aug = F.softmax(zc_aug_logit, dim=1)
                entropy_loss = en_loss(zc) + en_loss(zc_aug)
                print(zc)
                with torch.no_grad():
                    zc_aug_logit1= encoder1(x_aug)
                    zc_logit1 = encoder1(x)

                # zc1 = F.softmax(zc_logit1, dim=1)
                # zc_aug1 = F.softmax(zc_aug_logit1, dim=1)

                adv_e_loss = args.beta_adv * (- torch.mean(critic(zc)) - torch.mean(critic(zc_aug)))
                # print(torch.mean(critic(zc)),torch.mean(critic(zc_aug)))
                # sim1 = similarity_f(zc.unsqueeze(1),zc_aug1.unsqueeze(0))
                # sim2 = similarity_f(zc_aug.unsqueeze(1),zc1.unsqueeze(0))
                #
                # on_diag_c = torch.diagonal(sim1)
                # off_diag_c = 1 * off_diagonal(sim1)
                #
                # on_diag_c1 = torch.diagonal(sim2)
                # off_diag_c1 = 1 * off_diagonal(sim2)
                #
                # N = on_diag_c.size(0)
                # N1 = on_diag_c1.size(0)
                #
                # positive_clusters = on_diag_c.reshape(N, 1)
                # negative_clusters = off_diag_c.reshape(N, -1)
                #
                # positive_clusters1 = on_diag_c1.reshape(N1, 1)
                # negative_clusters1 = off_diag_c1.reshape(N1, -1)
                #
                # labels = torch.zeros(N).to(positive_clusters.device).long()
                # logits = torch.cat((positive_clusters, negative_clusters), dim=1)
                #
                # labels1 = torch.zeros(N1).to(positive_clusters1.device).long()
                # logits1 = torch.cat((positive_clusters1, negative_clusters1), dim=1)
                #
                # loss = 4 * self.criterion(logits1, labels1) / N1 + 1 * self.criterion(logits, labels) / N

                # aug loss
                aug_loss = 1 * kl_div_loss(F.log_softmax(zc_aug_logit, dim=1), zc) + \
                           1 * kl_div_loss(F.log_softmax(zc_logit, dim=1), zc_aug) + \
                           args.beta_aug * kl_div_loss(F.log_softmax(zc_aug_logit1, dim=1).detach(), zc) + \
                           args.beta_aug * kl_div_loss(F.log_softmax(zc_logit1, dim=1).detach(), zc_aug)

                e_loss = 1 * adv_e_loss + 1 * aug_loss
            # print(entropy_loss)
            scaler.scale(e_loss).backward(retain_graph=True)
            scaler.step(optimizer_e)
            scaler.update()

            update_moving_average(
                target_ema_updater, encoder1, encoder
            )

            train_adv_e_loss.update(adv_e_loss.item(), n=b)
            train_aug_loss.update(1 * aug_loss.item(), n=b)
            #
        else:
            with torch.no_grad():
                zc_logit = encoder(x)
            zc = F.softmax(zc_logit, dim=1)

            zs_prior, zc_prior, _ = utils.sample_z(b, dim_zs=args.dim_zs, dim_zc=args.dim_zc, zs_std=args.zs_std)
            zc_prior = torch.tensor(zc_prior, dtype=torch.float32, device=device)
            c_real_loss = -torch.mean(critic(zc_prior))
            c_fake_loss = torch.mean(critic(zc))
            gradient_penalty = utils.calc_gradient_penalty(critic, zc_prior, zc, args.lambda_gp)
            adv_c_loss = args.beta_adv * (c_real_loss + c_fake_loss + gradient_penalty)
            optimizer_c.zero_grad()
            adv_c_loss.backward(retain_graph=True)
            optimizer_c.step()

            with torch.no_grad():
                zc_aug_logit = encoder(x_aug)
            zc_aug = F.softmax(zc_aug_logit, dim=1)
            c_real_loss = - torch.mean(critic(zc_prior))
            c_fake_loss_aug = torch.mean(critic(zc_aug))
            c_fake_loss = torch.mean(critic(zc))
            m_loss = mse_loss(c_fake_loss_aug, c_fake_loss)
            gradient_penalty = utils.calc_gradient_penalty(critic, zc_prior, zc_aug, args.lambda_gp)
            adv_c_loss = args.beta_adv * (c_real_loss + c_fake_loss_aug + gradient_penalty) + 1 * m_loss
            # print(adv_c_loss,args.beta_adv * (c_real_loss + c_fake_loss_aug + gradient_penalty),100 * m_loss)
            train_adv_c_loss.update(adv_c_loss.item(), n=b)

            optimizer_c.zero_grad()
            adv_c_loss.backward()
            optimizer_c.step()

            #
            #     with torch.no_grad():
            #         zs_top2_aug, zc_top2_aug_logit, _ = encoder(x_neighbor_top2)
            #     zc = F.softmax(zc_top2_aug_logit, dim=1)
            #     zs_prior, zc_prior, _ = utils.sample_z(b, dim_zs=args.dim_zs, dim_zc=args.dim_zc, zs_std=args.zs_std)
            #     zc_prior = torch.tensor(zc_prior, dtype=torch.float32, device=device)
            #     c_real_loss = -torch.mean(critic(zc_prior))
            #     c_fake_loss = torch.mean(critic(zc))
            #     gradient_penalty = utils.calc_gradient_penalty(critic, zc_prior, zc, args.lambda_gp)
            #     adv_c_loss = args.beta_adv * (c_real_loss + c_fake_loss + gradient_penalty)
            #     optimizer_c.zero_grad()
            #     adv_c_loss.backward(retain_graph=True)
            #     optimizer_c.step()
            #
            #     with torch.no_grad():
            #         zs_top3_aug, zc_top3_aug_logit, _ = encoder(x_neighbor_top3)
            #     zc = F.softmax(zc_top3_aug_logit, dim=1)
            #     zs_prior, zc_prior, _ = utils.sample_z(b, dim_zs=args.dim_zs, dim_zc=args.dim_zc, zs_std=args.zs_std)
            #     zc_prior = torch.tensor(zc_prior, dtype=torch.float32, device=device)
            #     c_real_loss = -torch.mean(critic(zc_prior))
            #     c_fake_loss = torch.mean(critic(zc))
            #     gradient_penalty = utils.calc_gradient_penalty(critic, zc_prior, zc, args.lambda_gp)
            #     adv_c_loss = args.beta_adv * (c_real_loss + c_fake_loss + gradient_penalty)
            #     optimizer_c.zero_grad()
            #     adv_c_loss.backward(retain_graph=True)
            #     optimizer_c.step()
        # with torch.no_grad():
        #     zs, zc_logit, projection = encoder(x)
        #     zc = F.softmax(zc_logit, dim=1)
        #     org_feat_memory.push(zc.clone().detach(), data['meta']['index'])
        # if i % 500 == 0 and i != 0:
        #     r = random.randint(0,b-1)
        #     z1 = np.argmax(zc.cpu().detach().numpy(), axis=1)
        #     z2 = np.argmax(zc_aug.cpu().detach().numpy(), axis=1)
        #     print(z1-z2)
        #     print(zc[r])
        #     print(zc_aug[r])
        #     print('----------------------------------------------')
        train_batch_time.update(time.time() - tic)

        global_step += 1
        tic = time.time()
    print(time.time() - tic1)
    file_logger.info('Epoch {0} (train):\t'
                     'data_time: {data_time.sum:.2f}s\t'
                     'batch_time: {batch_time.sum:.2f}s\t'
                     'mi_loss: {mi_loss.avg:.4f}\t'
                     'aug_loss: {aug_loss.avg:.4f}\t'
                     'adv_e_loss: {adv_e_loss.avg:.4f}\t'
                     'adv_c_loss: {adv_c_loss.avg:.4f}\t'.format(
        epoch, data_time=train_data_time, batch_time=train_batch_time, mi_loss=train_mi_loss,
        aug_loss=train_aug_loss, adv_e_loss=train_adv_e_loss, adv_c_loss=train_adv_c_loss))

    writer.add_scalars('mi_loss', {'train': train_mi_loss.avg}, epoch)
    writer.add_scalars('aug_loss', {'train': train_aug_loss.avg}, epoch)
    writer.add_scalars('adv_e_loss', {'train': train_adv_e_loss.avg}, epoch)
    writer.add_scalars('adv_c_loss', {'train': train_adv_c_loss.avg}, epoch)

    return global_step
from sklearn.neighbors import NearestNeighbors

def eval_epoch(eval_loader, model_byol, critic, sobel, device, epoch, checkpoint_path, file_logger, writer,
               best_metrics, args):
    max_acc, max_nmi, max_ari = best_metrics

    eval_data_time = utils.AverageMeter()
    eval_batch_time = utils.AverageMeter()
    transforms1 = torchvision.transforms.Compose([
        torchvision.transforms.Resize(224),
        torchvision.transforms.ToTensor(),
        torchvision.transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]),
    ])
    imgs = list()
    zc = list()
    y_true = list()

    model_byol.eval()

    tic = time.time()
    with torch.no_grad():
        for data in eval_loader:
            eval_data_time.update(time.time() - tic)
            x, y_true_ = data
            x = x.to(device, non_blocking=True)
            zc_logit = model_byol(x)
            zc_ = F.softmax(zc_logit,dim=1)
            imgs.append(x.cpu().numpy())
            zc.append(zc_.cpu().numpy())
            y_true.append(y_true_.cpu().numpy())
            eval_batch_time.update(time.time() - tic)
            tic = time.time()

    imgs = np.concatenate(imgs, axis=0)
    zc = np.concatenate(zc, axis=0)
    y_true = np.concatenate(y_true, axis=0)

    # calculate metrics
    y_pred = np.argmax(zc, axis=1)

    num_classes = zc.shape[1]
    match = utils.hungarian_match(y_pred, y_true, num_classes)
    y_pred = utils.convert_cluster_assignment_to_ground_truth(y_pred, match)

    acc = metrics.accuracy(y_pred, y_true)
    nmi = metrics.nmi(y_pred, y_true)
    ari = metrics.ari(y_pred, y_true)

    max_acc = max(max_acc, acc)
    max_nmi = max(max_nmi, nmi)
    max_ari = max(max_ari, ari)

    tic = time.time()
    # save some images
    if epoch == 0:
        real_img_idx = np.random.choice(np.arange(len(eval_loader.dataset)), 100, replace=False)
        imgs_ = torch.tensor(imgs[real_img_idx], dtype=torch.float32)
        if args.img_type == 'sobel':
            torchvision.utils.save_image(imgs_[:, :1], os.path.join(checkpoint_path, 'img', 'real_x.jpg'), nrow=10,
                                         padding=0, normalize=True, range=(-1, 1))
            torchvision.utils.save_image(imgs_[:, 1:], os.path.join(checkpoint_path, 'img', 'real_y.jpg'), nrow=10,
                                         padding=0, normalize=True, range=(-1, 1))
        else:
            torchvision.utils.save_image(imgs_, os.path.join(checkpoint_path, 'img', 'real.jpg'), nrow=10,
                                         padding=0, normalize=True, range=(-1, 1))
    cluster_imgs = list()
    for cls in range(num_classes):
        cls_score = zc[:, cls]
        idxs = np.argsort(cls_score)[::-1][:10]
        cluster_imgs.append(imgs[idxs])
    cluster_imgs = np.concatenate(cluster_imgs, axis=0)
    cluster_imgs = torch.tensor(cluster_imgs, dtype=torch.float32)
    if args.img_type == 'sobel':
        torchvision.utils.save_image(cluster_imgs[:, :1],
                                     os.path.join(checkpoint_path, 'img', 'cluster_imgs_%03d_x.jpg' % epoch),
                                     nrow=10, padding=0, normalize=True, range=(-1, 1))
        torchvision.utils.save_image(cluster_imgs[:, 1:],
                                     os.path.join(checkpoint_path, 'img', 'cluster_imgs_%03d_y.jpg' % epoch),
                                     nrow=10, padding=0, normalize=True, range=(-1, 1))
    else:
        torchvision.utils.save_image(cluster_imgs,
                                     os.path.join(checkpoint_path, 'img', 'cluster_imgs_%03d.jpg' % epoch), nrow=10,
                                     padding=0, normalize=True, range=(-1, 1))

    # save tsne image
    idxs = np.random.choice(np.arange(len(eval_loader.dataset)), 1000, replace=False)
    visualization.tsne(zc[idxs], y=y_true[idxs], show_legend=False,
                       save_path=os.path.join(checkpoint_path, 'img', 'tsne_%03d.jpg' % epoch), show_fig=False)
    eval_save_time = time.time() - tic

    file_logger.info('Epoch {0} (eval):\t'
                     'data_time: {data_time.sum:.2f}s\t'
                     'batch_time: {batch_time.sum:.2f}s\t'
                     'save_time: {save_time:.2f}s\t'
                     'acc: {acc:.2f}% ({max_acc:.2f}%)\t'
                     'nmi: {nmi:.4f} ({max_nmi:.4f})\t'
                     'ari: {ari:.4f} ({max_ari:.4f})\t'.format(epoch,
                                                               data_time=eval_data_time, batch_time=eval_batch_time,
                                                               save_time=eval_save_time,
                                                               acc=acc, max_acc=max_acc, nmi=nmi, max_nmi=max_nmi,
                                                               ari=ari, max_ari=max_ari))
    writer.add_scalars('acc', {'val': acc}, epoch)
    writer.add_scalars('nmi', {'val': nmi}, epoch)
    writer.add_scalars('ari', {'val': ari}, epoch)

    return max_acc, max_nmi, max_ari


if __name__ == '__main__':
    _main()
