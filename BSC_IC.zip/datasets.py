# -*- coding: UTF-8 -*-

import os
import random
from torch.utils.data import Dataset, ConcatDataset
import torchvision
import numpy as np
from PIL import Image


def channel_shuffle_fn(img):
    img = np.array(img, dtype=np.uint8)

    channel_idx = list(range(img.shape[-1]))
    random.shuffle(channel_idx)

    img = img[:, :, channel_idx]

    img = Image.fromarray(img, 'RGB')
    return img


class ClusterDataset(Dataset):
    def __init__(self, root, dataset_type, img_type, training=True):

        assert img_type in ['rgb', 'grayscale', 'sobel']

        self.training = training

        if dataset_type == 'MNIST':
            dataset_train = torchvision.datasets.MNIST(root, train=True,download=True)
            dataset_test = torchvision.datasets.MNIST(root, train=False)
            self.dataset = ConcatDataset([dataset_train, dataset_test])
        elif dataset_type == 'FashionMNIST':
            dataset_train = torchvision.datasets.FashionMNIST(root, train=True)
            dataset_test = torchvision.datasets.FashionMNIST(root, train=False)
            self.dataset = ConcatDataset([dataset_train, dataset_test])
        elif dataset_type == 'CIFAR10':
            dataset_train = torchvision.datasets.CIFAR10(root, train=True,download=True)
            dataset_test = torchvision.datasets.CIFAR10(root, train=False,download=True)
            self.dataset = ConcatDataset([dataset_train, dataset_test])
        # elif dataset_type == 'CIFAR100':
        #     dataset_train = torchvision.datasets.CIFAR10(root, train=True,download=True)
        #     dataset_test = torchvision.datasets.CIFAR10(root, train=False,download=True)
            self.dataset = ConcatDataset([dataset_train, dataset_test])
        elif dataset_type == 'STL10':
            dataset_train = torchvision.datasets.STL10(root, split='train')
            dataset_test = torchvision.datasets.STL10(root, split='test')
            self.dataset = ConcatDataset([dataset_train, dataset_test])
        elif dataset_type == 'CIFAR-100':
            dataset_train = torchvision.datasets.CIFAR100(root, train=True,download=True)
            dataset_test = torchvision.datasets.CIFAR100(root, train=False,download=True)
            self.dataset = ConcatDataset([dataset_train, dataset_test])
        elif dataset_type == 'USPS':
            dataset_train = torchvision.datasets.USPS(root, train=True,download=True)
            dataset_test = torchvision.datasets.USPS(root, train=False,download=True)
            self.dataset = ConcatDataset([dataset_train, dataset_test])
        elif dataset_type in ['ImageNet10']:
            # The directory is like:
            # root
            # |-- cls1
            # |-- |-- img1
            # |-- |-- img2
            # |-- |-- ...
            # |-- cls2
            # |-- ...
            classes = sorted(os.listdir(root))
            self.dataset = list()
            for idx, cls in enumerate(classes):
                for img_fp in sorted(os.listdir(os.path.join(root, cls))):
                    img = Image.open(os.path.join(root, cls, img_fp)).convert('RGB')
                    self.dataset.append((img, idx))
        elif dataset_type in ['TinyImageNet']:
            dataset_train = torchvision.datasets.ImageFolder(root='datasets/tiny-imagenet-200/train')
            dataset_test = torchvision.datasets.ImageFolder(root='datasets/tiny-imagenet-200/train')
            self.dataset = ConcatDataset([dataset_train, dataset_test])
        else:
            raise NotImplementedError

        if dataset_type in ['MNIST', 'FashionMNIST', 'USPS']:
            if img_type == 'rgb':
                raise ValueError

            self.transforms = torchvision.transforms.Compose([
                torchvision.transforms.Resize(28),
                torchvision.transforms.ToTensor(),
                torchvision.transforms.Normalize(mean=[0.5], std=[0.5]),
            ])

            aug_list = list()
            aug_list.append(torchvision.transforms.RandomResizedCrop(28, scale=(0.4, 1.0), ratio=(3. / 4., 4. / 3.)))
            if dataset_type != 'MNIST' or dataset_type != 'USPS':
                aug_list.append(torchvision.transforms.RandomHorizontalFlip(p=0.5))
            aug_list.append(torchvision.transforms.ToTensor())
            aug_list.append(torchvision.transforms.Normalize(mean=[0.5], std=[0.5]))
            self.transforms_aug = torchvision.transforms.Compose(aug_list)

        elif dataset_type in ['CIFAR10', 'STL10', 'ImageNet10','TinyImageNet']:
            if dataset_type == 'CIFAR10':
                img_size = 32
            else:
                img_size = 96

            if img_type == 'rgb':
                self.transforms = torchvision.transforms.Compose([
                    torchvision.transforms.Resize(img_size),
                    torchvision.transforms.ToTensor(),
                    torchvision.transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]),
                ])
            else:
                self.transforms = torchvision.transforms.Compose([
                    torchvision.transforms.Grayscale(num_output_channels=1),
                    torchvision.transforms.ToTensor(),
                    torchvision.transforms.Normalize(mean=[0.5], std=[0.5]),
                ])
            s = 0.5
            color_jitter = torchvision.transforms.ColorJitter(
                0.8 * s, 0.8 * s, 0.8 * s, 0.2 * s
            )
            aug_list = list()
            aug_list.append(
                torchvision.transforms.RandomResizedCrop(img_size, scale=(0.4, 1.0), ratio=(3. / 4., 4. / 3.)))
            aug_list.append(torchvision.transforms.RandomHorizontalFlip(p=0.5))
            # aug_list.append(channel_shuffle_fn)
            aug_list.append(torchvision.transforms.RandomApply([color_jitter], p=0.8))
            aug_list.append(torchvision.transforms.RandomGrayscale(p=0.2))
            aug_list.append(torchvision.transforms.ToTensor())
            if img_type == 'rgb':
                aug_list.append(torchvision.transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]))
            else:
                aug_list.append(torchvision.transforms.Normalize(mean=[0.5], std=[0.5]))
            self.transforms_aug = torchvision.transforms.Compose(aug_list)

        elif dataset_type in ['CIFAR-100']:
            size = 32
            s = 0.5
            aug_list = [
                torchvision.transforms.RandomResizedCrop(size=size),
                torchvision.transforms.RandomHorizontalFlip(),
                torchvision.transforms.RandomApply(
                    [torchvision.transforms.ColorJitter(0.8 * s, 0.8 * s, 0.8 * s, 0.2 * s)],
                    p=0.8),
                torchvision.transforms.RandomGrayscale(p=0.2),
                torchvision.transforms.ToTensor(),
                torchvision.transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
            ]
            self.transforms = torchvision.transforms.Compose([
                torchvision.transforms.ToTensor(),
                torchvision.transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]),
            ])
            self.transforms_aug = torchvision.transforms.Compose(aug_list)
        else:
            raise NotImplementedError

    def __getitem__(self, item):
        img_raw, label = self.dataset[item]

        img = self.transforms(img_raw)
        img_t = self.transforms_aug(img_raw)
        if self.training:
            img_aug = self.transforms_aug(img_raw)
            return img_t, img_aug
        else:
            return img, label

    def __len__(self):
        return len(self.dataset)
