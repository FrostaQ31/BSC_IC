# -*- coding: UTF-8 -*-

import torch
import torch.nn as nn
import layers
import torchvision.models as md
import torchvision.models as models

def get_encoder(dataset_type, img_type, dim_zs, dim_zc,online):
    if img_type == 'rgb':
        img_dim = 3
    elif img_type == 'grayscale':
        img_dim = 1
    elif img_type == 'sobel':
        img_dim = 2
    else:
        raise ValueError

    if dataset_type in ['MNIST', 'FashionMNIST', 'USPS']:
        if online==True :
            return Encoder28_online(img_dim, dim_zs, dim_zc, return_act=True)
        else:
            return Encoder28_target(img_dim, dim_zs, dim_zc, return_act=True)
    elif dataset_type in ['CIFAR10','CIFAR-100']:
        if online==True :
            return Encoder32_online(img_dim, 128, dim_zs, dim_zc, return_act=True, norm_type='bn', momentum=0.1)
        else:
            return Encoder32_target(img_dim, 128, dim_zs, dim_zc, return_act=True, norm_type='bn', momentum=0.1)
    elif dataset_type in ['STL10', 'ImageNet10']:
        if online==True :
            return Encoder96_online(img_dim, 128, dim_zs, dim_zc, return_act=True, norm_type='bn', momentum=0.1)
        else:
            return Encoder96_target(img_dim, 128, dim_zs, dim_zc, return_act=True, norm_type='bn', momentum=0.1)
    elif dataset_type in ['TinyImageNet']:
        if online==True :
            return Encoder96(img_dim, 128, dim_zs, dim_zc, return_act=True, norm_type='bn', momentum=0.1)
        else:
            return Encoder96(img_dim, 128, dim_zs, dim_zc, return_act=True, norm_type='bn', momentum=0.1)

    else:
        raise NotImplementedError


def get_critic(dim_zs, dim_zc):
    return Critic(dim_zs, dim_zc)

def get_critic1(dim_zs, dim_zc):
    return Critic1(dim_zs, dim_zc)

def get_discriminator(dataset_type, dim_zs, dim_zc):
    if dataset_type in ['MNIST', 'FashionMNIST']:
        return Discriminator(5 * 5 * 128, dim_zs + dim_zc)
    elif dataset_type in ['CIFAR10']:
        return Discriminator(4 * 4 * 128 * 4, dim_zs + dim_zc)
    elif dataset_type in ['STL10', 'ImageNet10']:
        return Discriminator(6 * 6 * 64 * 8, dim_zs + dim_zc)
    else:
        raise NotImplementedError


class Encoder28_online(nn.Module):
    def __init__(self, img_dim, dim_zs=30, dim_zc=10, return_act=False):
        super(Encoder28_online, self).__init__()

        self.dim_zs = dim_zs
        self.return_act = return_act

        self.backbone = nn.Sequential(
            nn.Conv2d(img_dim, 64, 4, stride=2, bias=False),
            nn.BatchNorm2d(64),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(64, 128, 4, stride=2, bias=False),
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2, inplace=True),
        )

        self.fc1 = nn.Sequential(
            nn.Linear(5 * 5 * 128, 1024, bias=False),
            nn.BatchNorm1d(1024),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(1024, 10, bias=True),
        )

        self.fc2 = nn.Sequential(
            nn.Linear(5 * 5 * 128, 1024, bias=False),
            nn.BatchNorm1d(1024),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(1024, dim_zc * 2, bias=True),
        )
        self.reset_parameters()

    def reset_parameters(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d) or isinstance(m, nn.BatchNorm1d) or isinstance(m, nn.GroupNorm):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, x, online=True):
        # x: [b, img_dim, 28, 28]
        b = x.size(0)
        out = self.backbone(x)
        out = out.view(b, -1)
        out1 = self.fc1(out)
        out2 = self.fc2(out)
        return out1, out2

class Encoder28_target(nn.Module):
    def __init__(self, img_dim, dim_zs=30, dim_zc=10, return_act=False):
        super(Encoder28_target, self).__init__()

        self.dim_zs = dim_zs
        self.return_act = return_act

        self.backbone = nn.Sequential(
            nn.Conv2d(img_dim, 64, 4, stride=2, bias=False),
            nn.BatchNorm2d(64),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(64, 128, 4, stride=2, bias=False),
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2, inplace=True),
        )

        self.fc1 = nn.Sequential(
            nn.Linear(5 * 5 * 128, 1024, bias=False),
            nn.BatchNorm1d(1024),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(1024, dim_zc, bias=True),
        )

        self.fc2 = nn.Sequential(
            nn.Linear(5 * 5 * 128, 1024, bias=False),
            nn.BatchNorm1d(1024),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(1024, 2 * dim_zc, bias=True),
        )

        self.reset_parameters()

    def reset_parameters(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d) or isinstance(m, nn.BatchNorm1d) or isinstance(m, nn.GroupNorm):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, x, online=True):
        # x: [b, img_dim, 28, 28]
        b = x.size(0)
        out = self.backbone(x)
        out = out.view(b, -1)
        out1 = self.fc1(out)
        out2 = self.fc2(out)
        return out1, out2


class Encoder32_online(nn.Module):
    def __init__(self, img_dim=3, num_channels=128, dim_zs=30, dim_zc=10, return_act=False, norm_type='bn', **kwargs):
        super(Encoder32_online, self).__init__()

        self.dim_zs = dim_zs
        self.return_act = return_act
        # [32, 32] -> [16, 16]
        self.backbone = nn.Sequential(
            layers.OptimizedResBlockDown(img_dim, num_channels, norm_type=norm_type, **kwargs),
            layers.ResBlock(num_channels, num_channels * 2, sample_type='down', norm_type=norm_type, **kwargs),
            layers.ResBlock(num_channels * 2, num_channels * 4, sample_type='down', norm_type=norm_type,
                            **kwargs),
            layers.ResBlock(num_channels * 4, num_channels * 4, sample_type='none', norm_type=norm_type,
                            **kwargs),
            layers.Norm2dLayer(num_channels * 4, norm_type=norm_type, **kwargs),
            nn.ReLU(inplace=True),
            nn.AvgPool2d(kernel_size=4),
            nn.Conv2d(num_channels * 4, 512, kernel_size=1, bias=True)
        )

        self.fc1 = nn.Sequential(
            nn.Linear(512, 512, bias=False),
            nn.BatchNorm1d(512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, dim_zc, bias=True),
        )

        self.fc2 = nn.Sequential(
            nn.Linear(512, 512, bias=False),
            nn.BatchNorm1d(512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 2 * dim_zc, bias=True),
        )
        self.reset_parameters()

    def reset_parameters(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d) or isinstance(m, nn.GroupNorm):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, x):
        # x: [b, img_dim, 32, 32]
        b = x.size(0)
        out = self.backbone(x)
        c = out.size(1)
        out = out.view(b, c)
        out1 = self.fc1(out)
        out2 = self.fc2(out)
        # print(out1.size(),out2.size())
        return out1, out2


class Encoder32_target(nn.Module):
    def __init__(self, img_dim=3, num_channels=128, dim_zs=30, dim_zc=10, return_act=False, norm_type='bn', **kwargs):
        super(Encoder32_target, self).__init__()

        self.dim_zs = dim_zs
        self.return_act = return_act

        # [32, 32] -> [16, 16]
        self.backbone = nn.Sequential(
            layers.OptimizedResBlockDown(img_dim, num_channels, norm_type=norm_type, **kwargs),
            layers.ResBlock(num_channels, num_channels * 2, sample_type='down', norm_type=norm_type, **kwargs),
            layers.ResBlock(num_channels * 2, num_channels * 4, sample_type='down', norm_type=norm_type,
                            **kwargs),
            layers.ResBlock(num_channels * 4, num_channels * 4, sample_type='none', norm_type=norm_type,
                            **kwargs),
            layers.Norm2dLayer(num_channels * 4, norm_type=norm_type, **kwargs),
            nn.ReLU(inplace=True),
            nn.AvgPool2d(kernel_size=4),
            nn.Conv2d(num_channels * 4, 512, kernel_size=1, bias=True)
        )
        self.fc1 = nn.Sequential(
            nn.Linear(512, 512, bias=False),
            nn.BatchNorm1d(512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, dim_zc, bias=True),
        )

        self.fc2 = nn.Sequential(
            nn.Linear(512, 512, bias=False),
            nn.BatchNorm1d(512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, dim_zc *2, bias=True),
        )
        self.reset_parameters()

    def reset_parameters(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d) or isinstance(m, nn.GroupNorm):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, x):
        # x: [b, img_dim, 32, 32]
        b = x.size(0)
        out = self.backbone(x)
        c = out.size(1)
        out = out.view(b, c)
        out1 = self.fc1(out)
        out2 = self.fc2(out)

        return out1, out2

# class Encoder96_online(nn.Module):
#     def __init__(self, img_dim, num_channels, dim_zs=30, dim_zc=10, return_act=False, norm_type='bn', **kwargs):
#         super(Encoder96_online, self).__init__()
#
#         self.dim_zs = dim_zs
#         self.return_act = return_act
#         self.backbone = md.resnet34(pretrained=False)
#         num_fc_ftr = self.backbone.fc.in_features
#         self.backbone.fc = nn.Sequential(torch.nn.Linear(num_fc_ftr, num_fc_ftr),
#                                          torch.nn.Linear(num_fc_ftr, dim_zc))
#
#         # self.mlp1 = MLP(dim_zs + dim_zc, dim_zs + dim_zc)
#         self.reset_parameters()
#
#     def reset_parameters(self):
#         for m in self.modules():
#             if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
#                 nn.init.xavier_normal_(m.weight)
#                 if m.bias is not None:
#                     nn.init.zeros_(m.bias)
#             elif isinstance(m, nn.BatchNorm2d) or isinstance(m, nn.GroupNorm):
#                 nn.init.ones_(m.weight)
#                 nn.init.zeros_(m.bias)
#
#     def forward(self, x):
#         # x: [b, img_dim, 32, 32]
#         out = self.backbone(x)
#         return out
#
#
# class Encoder96_target(nn.Module):
#     def __init__(self, img_dim, num_channels, dim_zs=30, dim_zc=10, return_act=False, norm_type='bn', **kwargs):
#         super(Encoder96_target, self).__init__()
#
#         self.dim_zs = dim_zs
#         self.return_act = return_act
#         self.backbone = md.resnet34(pretrained=False)
#         num_fc_ftr = self.backbone.fc.in_features
#         self.backbone.fc = nn.Sequential(torch.nn.Linear(num_fc_ftr, num_fc_ftr),
#                                          torch.nn.Linear(num_fc_ftr, dim_zc))
#
#         self.reset_parameters()
#
#     def reset_parameters(self):
#         for m in self.modules():
#             if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
#                 nn.init.xavier_normal_(m.weight)
#                 if m.bias is not None:
#                     nn.init.zeros_(m.bias)
#             elif isinstance(m, nn.BatchNorm2d) or isinstance(m, nn.GroupNorm):
#                 nn.init.ones_(m.weight)
#                 nn.init.zeros_(m.bias)
#
#     def forward(self, x):
#         # x: [b, img_dim, 32, 32]
#         out = self.backbone(x)
#         return out
# class Encoder96_online(nn.Module):
#     def __init__(self, img_dim, num_channels, dim_zs=30, dim_zc=10, return_act=False, norm_type='bn', **kwargs):
#         super(Encoder96_online, self).__init__()
#         self.res = models.resnet18(pretrained=False)
#         num_ftrs = self.res.fc.in_features
#         self.res.fc = nn.Linear(num_ftrs, 10)
#
#     def forward(self, x):
#         out = self.res(x)
#         return out, out
#
#
# class Encoder96_target(nn.Module):
#     def __init__(self, img_dim, num_channels, dim_zs=30, dim_zc=10, return_act=False, norm_type='bn', **kwargs):
#         super(Encoder96_target, self).__init__()
#         self.res = models.resnet18(pretrained=False)
#         num_ftrs = self.res.fc.in_features
#         self.res.fc = nn.Linear(num_ftrs, 10)
#
#     def forward(self, x):
#         out = self.res(x)
#         return out, out

class Encoder96_online(nn.Module):
    def __init__(self, img_dim, num_channels, dim_zs=30, dim_zc=10, return_act=False, norm_type='bn', **kwargs):
        super(Encoder96_online, self).__init__()

        self.dim_zs = dim_zs
        self.return_act = return_act
        self.backbone = nn.Sequential(
            layers.OptimizedResBlockDown(img_dim, num_channels, norm_type=norm_type, **kwargs),
            layers.ResBlock(num_channels, num_channels * 2, sample_type='down', norm_type=norm_type, **kwargs),
            layers.ResBlock(num_channels * 2, num_channels * 4, sample_type='down', norm_type=norm_type,**kwargs),
            layers.ResBlock(num_channels * 4, num_channels * 8, sample_type='down', norm_type=norm_type,
                            **kwargs),
            layers.ResBlock(num_channels * 8, num_channels * 8, sample_type='none', norm_type=norm_type,
                            **kwargs),
            layers.Norm2dLayer(num_channels * 8, norm_type=norm_type, **kwargs),
            nn.ReLU(inplace=True),
            nn.AvgPool2d(kernel_size=6),
            nn.Conv2d(num_channels * 8, 512, kernel_size=1, bias=True)
        )
        self.fc1 = nn.Sequential(
            nn.Linear(512, 512, bias=False),
            nn.BatchNorm1d(512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, dim_zc, bias=True),
        )

        self.fc2 = nn.Sequential(
            nn.Linear(512, 512, bias=False),
            nn.BatchNorm1d(512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 2 * dim_zc, bias=True),
        )
        self.reset_parameters()

    def reset_parameters(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d) or isinstance(m, nn.GroupNorm):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, x):
        # x: [b, img_dim, 96, 96]
        b = x.size(0)
        out = self.backbone(x)
        c = out.size(1)
        out = out.view(b, c)
        out1 = self.fc1(out)
        out2 = self.fc2(out)

        return out1, out2

class Encoder96_target(nn.Module):
    def __init__(self, img_dim, num_channels, dim_zs=30, dim_zc=10, return_act=False, norm_type='bn', **kwargs):
        super(Encoder96_target, self).__init__()

        self.dim_zs = dim_zs
        self.return_act = return_act
        self.backbone = nn.Sequential(
            layers.OptimizedResBlockDown(img_dim, num_channels, norm_type=norm_type, **kwargs),
            layers.ResBlock(num_channels, num_channels * 2, sample_type='down', norm_type=norm_type, **kwargs),
            layers.ResBlock(num_channels * 2, num_channels * 4, sample_type='down', norm_type=norm_type,**kwargs),
            layers.ResBlock(num_channels * 4, num_channels * 8, sample_type='down', norm_type=norm_type,
                            **kwargs),
            layers.ResBlock(num_channels * 8, num_channels * 8, sample_type='none', norm_type=norm_type,
                            **kwargs),
            layers.Norm2dLayer(num_channels * 8, norm_type=norm_type, **kwargs),
            nn.ReLU(inplace=True),
            nn.AvgPool2d(kernel_size=6),
            nn.Conv2d(num_channels * 8, 512, kernel_size=1, bias=True)
        )
        self.fc1 = nn.Sequential(
            nn.Linear(512, 512, bias=False),
            nn.BatchNorm1d(512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, dim_zc, bias=True),
        )

        self.fc2 = nn.Sequential(
            nn.Linear(512, 512, bias=False),
            nn.BatchNorm1d(512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 2 * dim_zc, bias=True),
        )
        self.reset_parameters()

    def reset_parameters(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d) or isinstance(m, nn.GroupNorm):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, x):
        # x: [b, img_dim, 96, 96]
        b = x.size(0)

        out = self.backbone(x)
        c = out.size(1)
        out = out.view(b, c)
        out1 = self.fc1(out)
        out2 = self.fc2(out)

        return out1, out2

class Critic(nn.Module):
    def __init__(self, dim_zs=30, dim_zc=10):
        super(Critic, self).__init__()

        self.fc = nn.Sequential(
            nn.Linear(dim_zc, 1024, bias=True),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(1024, 512, bias=True),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 1, bias=True),
        )

        self.reset_parameters()

    def reset_parameters(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, z):
        # z: [b, dim_zs + dim_zc]
        out = self.fc(z)
        return out

class Critic1(nn.Module):
    def __init__(self, dim_zs=30, dim_zc=10):
        super(Critic1, self).__init__()

        self.fc = nn.Sequential(
            nn.Linear(2 * dim_zc, 1024, bias=True),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(1024, 512, bias=True),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 1, bias=True),
        )

        self.reset_parameters()

    def reset_parameters(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, z):
        # z: [b, dim_zs + dim_zc]
        out = self.fc(z)
        return out

class MLP(nn.Module):
    def __init__(self, dim, projection_size, hidden_size=4096):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_size),
            nn.BatchNorm1d(hidden_size),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_size, projection_size),
        )

    def forward(self, x):
        return self.net(x)

class Discriminator(nn.Module):
    def __init__(self, x_channels, z_channels):
        super(Discriminator, self).__init__()

        self.net = nn.Sequential(
            nn.Linear(x_channels + z_channels, 1024, bias=True),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(1024, 512, bias=True),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(512, 1, bias=True),
        )

        self.reset_parameters()

    def reset_parameters(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x, z):
        # x: [b, x_channels]
        # z: [b, z_channels]
        logit = self.net(torch.cat([x, z], dim=1))
        return logit
