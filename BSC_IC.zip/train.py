# -*- coding: UTF-8 -*-

import os
import time
import random
import numpy as np
import argparse
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter
import layers
import models
import math
import datasets
import utils
import metrics
import visualization
from itertools import chain
import torchvision
import torchvision.models as md
from gcc.utils.aug_feat import AugFeat
from gcc.utils.config import create_config
from gcc.utils.common_config import get_criterion, get_model, get_train_dataset,\
                                get_val_dataset, get_train_dataloader,\
                                get_val_dataloader, get_train_transformations,\
                                get_val_transformations, get_optimizer,\
                                adjust_learning_rate
import faiss
from termcolor import colored
from gcc.utils.utils import fill_memory_bank, fill_memory_bank_mean
from gcc.utils.memory import MemoryBank
from gcc.utils.evaluate_utils import contrastive_evaluate, get_predictions, hungarian_evaluate
def _main():

    org_feat_memory = AugFeat('./org_feat_memory', 4)
    aug_feat_memory = AugFeat('./aug_feat_memory', 4)

    parser = argparse.ArgumentParser()
    parser.add_argument('--config_env', default='gcc/configs/env.yml',
                        help='Config file for the environment')

    parser.add_argument('--config_exp', default='gcc/configs/end2end/end2end_cifar10.yml',
                        help='Config file for the experiment')

    parser.add_argument('--dataset-type', type=str, default='CIFAR10',
                        choices=['MNIST', 'FashionMNIST', 'CIFAR10', 'STL10', 'ImageNet10'],
                        help='type of the dataset')

    parser.add_argument('--dataset-path', type=str, default='./datasets', help='path to the dataset')

    parser.add_argument('--img-type', type=str, default='rgb', choices=['rgb', 'grayscale', 'sobel'],
                        help='type of the image')

    parser.add_argument('--dim-zs', type=int, default = 128, help='dimension of zs')
    parser.add_argument('--dim-zc', type=int, default = 10, help='dimension of zc')
    parser.add_argument('--zs-std', type=float, default = 0.1,
                        help='standard deviation of the prior gaussian distribution for zs')

    parser.add_argument('--beta-mi', type=float, default=0, help='beta mi')
    parser.add_argument('--beta-adv', type=float, default=1., help='beta adv')
    parser.add_argument('--beta-aug', type=float, default=1., help='beta aug')

    parser.add_argument('--lambda-gp', type=float, default=10.0, help='gradient penalty coefficient')
    parser.add_argument('--skip-iter', type=int, default=1,
                        help='the number of critic iterations per encoder iteration')

    parser.add_argument('--batch-size', type=int, default=64, help='batch size')
    parser.add_argument('--lr', type=float, default=0.0003, help='learning rate')
    parser.add_argument('--epochs', type=int, default=3000,
                        help='number of epochs, note that you can early stop when the critic loss converges')

    parser.add_argument('--seed', type=int, default=111, help='random seed')
    parser.add_argument('--num-workers', type=int, default=8, help='number of workers for the dataloaders')
    parser.add_argument('--checkpoint-root', type=str, default='./checkpoint', help='path to the checkpoint root')
    parser.add_argument('--save-per-epochs', type=int, default=50, help='save the models per number of epochs')
    parser.add_argument('--model-name', type=str, default='DCCS', help='name of the model')
    parser.add_argument(
        "--resnet_version", default="resnet18", type=str, help="ResNet version."
    )
    parser.add_argument("--image-size", default=32, type=int, help="Image size")
    args = parser.parse_args()
    topk = 3
    p = create_config(args.config_env, args.config_exp)
    # create checkpoint directory
    # checkpoint_root/dataset_type/model_name/
    checkpoint_path = os.path.join(args.checkpoint_root, args.dataset_type, args.model_name)

    os.makedirs(checkpoint_path, exist_ok=True)
    # directory to save models
    os.makedirs(os.path.join(checkpoint_path, 'model'), exist_ok=True)
    # directory to save images
    os.makedirs(os.path.join(checkpoint_path, 'img'), exist_ok=True)

    # create logger
    console_logger, file_logger = utils.create_logger(os.path.join(checkpoint_path, 'train.log'))

    file_logger.info('Args: %s' % str(args))
    file_logger.info('Checkpoint path: %s' % checkpoint_path)

    # set seed
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    #dataset
    print(colored('Retrieve dataset', 'blue'))
    train_transforms = get_train_transformations(p)
    print('Train transforms:', train_transforms)
    val_transforms = get_val_transformations(p)
    print('Validation transforms:', val_transforms)
    train_dataset = get_train_dataset(p, train_transforms, to_end2end_dataset=True,
                                        split='train+unlabeled') # Split is for stl-10
    train_loader = get_train_dataloader(p, train_dataset)

    val_dataset = get_train_dataset(p, val_transforms, to_end2end_dataset=True,
                                        split='train') # Dataset w/o augs for knn eval
    eval_loader = get_val_dataloader(p, val_dataset)


    # Memory Bank
    print(colored('Build MemoryBank', 'blue'))
    base_dataset = get_train_dataset(p, val_transforms, to_end2end_dataset=True, split='train') # Dataset for performance test
    base_dataloader = get_val_dataloader(p, base_dataset)
    memory_bank_base = MemoryBank(len(base_dataset),
                                10,
                                p['num_classes'], p['criterion_kwargs']['temperature'])
    memory_bank_base.cuda()
    memory_bank_val = MemoryBank(len(val_dataset),
                                10,
                                p['num_classes'], p['criterion_kwargs']['temperature'])
    memory_bank_val.cuda()

    encoder = models.get_encoder(args.dataset_type, args.img_type, args.dim_zs, args.dim_zc,online=True)
    encoder1 = models.get_encoder(args.dataset_type, args.img_type, args.dim_zs, args.dim_zc,online=False)
    print(encoder)
    print(encoder1)


    critic = models.get_critic(args.dim_zs, args.dim_zc)

    sobel = layers.SobelLayer(normalize=True)

    w_batch = torch.tensor([60000,topk])
    # get device
    if torch.cuda.is_available():
        device = torch.device('cuda:0')
        num_gpus = torch.cuda.device_count()
        if num_gpus > 1:
            encoder = nn.DataParallel(encoder)
            encoder1 = nn.DataParallel(encoder1)
            critic = nn.DataParallel(critic)
            sobel = nn.DataParallel(sobel)
        file_logger.info('Using %d GPU' % num_gpus)
    else:
        device = torch.device('cpu')
        file_logger.info('Using CPU')
    encoder.to(device)
    encoder1.to(device)
    critic.to(device)
    sobel.to(device)
    # model_byol.to(device)
    # create optimizers
    optimizer_e = optim.Adam(encoder.parameters(), lr=args.lr, betas=(0.5, 0.9))
    optimizer_c = optim.Adam(critic.parameters(), lr=0.0001, betas=(0.5, 0.9))

    # create SummaryWriter
    writer = SummaryWriter(comment='_' + '_'.join([args.dataset_type, args.model_name]))

    if not os.path.exists(p['end2end_checkpoint']):
        print(colored('Restart from checkpoint {}'.format(p['end2end_checkpoint']), 'blue'))
        checkpoint = torch.load(p['end2end_checkpoint'], map_location='cpu')
        optimizer_e.load_state_dict(checkpoint['optimizer_e'])
        optimizer_c.load_state_dict(checkpoint['optimizer_c'])
        encoder.load_state_dict(checkpoint['model'])
        encoder1.load_state_dict(checkpoint['model1'])
        critic.load_state_dict(checkpoint['critic'])
        encoder.cuda()
        critic.cuda()
        start_epoch = 0  # 10000 for evaluate directly
    else:
        print(colored('No checkpoint file at {}'.format(p['end2end_checkpoint']), 'blue'))
        start_epoch = 0
        encoder.cuda()
        encoder1.cuda()
        critic.cuda()
    num_train = 500
    global_step = 0
    best_acc = 0.0
    for epoch in range(start_epoch, args.epochs):
        # train
        if epoch <= num_train:
            global_step = train_epoch(train_loader, encoder,encoder1, critic, sobel, device,w_batch,
                                  optimizer_e, optimizer_c, epoch, aug_feat_memory, org_feat_memory, p['log_output_file'],
                                      global_step, file_logger, writer, args, True)
        else:
            global_step = train_epoch(train_loader, encoder,encoder1, critic, sobel, device,w_batch,
                                      optimizer_e, optimizer_c, epoch, aug_feat_memory, org_feat_memory,
                                      p['log_output_file'], global_step, file_logger, writer, args, False)

        if epoch >= 0 and epoch % 1 == 0:
            print ("Start to evaluate...")
            predictions = get_predictions(p, base_dataloader, encoder)
            lowest_loss_head = 0
            clustering_stats = hungarian_evaluate(lowest_loss_head, predictions, compute_confusion_matrix=False)
            print(clustering_stats, len(base_dataloader.dataset))
            with open (p['log_output_file'], 'a+') as fw:
                fw.write(str(clustering_stats) + "\n")
            #
            # if clustering_stats['ACC'] > best_acc:
            #     best_acc = clustering_stats['ACC']
            #     print ('Best acc: ', best_acc)
            #
            #     print('Checkpoint ...')
            #     torch.save({'optimizer_e': optimizer_e.state_dict(), 'optimizer_c': optimizer_c.state_dict(),
            #                 'model': encoder.state_dict(),'model1': encoder1.state_dict(),'critic': critic.state_dict(),
            #                 'epoch': epoch + 1}, p['end2end_checkpoint'])

        if epoch >= num_train :
            if epoch == num_train:
                train_dataset = get_train_dataset(p, train_transforms, to_end2end_dataset=True,
                        split='train') # Split is for stl-10
                train_loader = get_train_dataloader(p, train_dataset)
            # Fill memory bank

            fill_memory_bank(train_loader, encoder,  memory_bank_base)
            distance, indices, acc, detail_acc = memory_bank_base.mine_nearest_neighbors(topk)
            w_batch = torch.from_numpy(distance)
            print(w_batch.size())
            distance_dict = memory_bank_base.laplace_transform(indices)
            print('Accuracy of top-%d nearest neighbors on val set is %.2f' %(topk, 100*acc))
            with open (p['log_output_file'], 'a+') as fw:
                for acc in detail_acc:
                    fw.write(acc)
            np.save(p['topk_neighbors_val_path'], indices)
            train_dataset.update_neighbors(indices)
            train_dataset.update_distance(distance_dict)

    writer.close()
class EMA:
    def __init__(self, beta):
        super().__init__()
        self.beta = beta

    def update_average(self, old, new):
        if old is None:
            return new
        return old * self.beta + (1 - self.beta) * new


def update_moving_average(ema_updater, ma_model, current_model):
    for current_params, ma_params in zip(
        current_model.parameters(), ma_model.parameters()
    ):
        old_weight, up_weight = ma_params.data, current_params.data
        ma_params.data = ema_updater.update_average(old_weight, up_weight)

def en_loss(c_i):
    p_i = c_i.sum(0).view(-1)
    p_i /= p_i.sum()
    ne_i = math.log(p_i.size(0)) + (p_i * torch.log(p_i)).sum()
    ne_loss = ne_i
    return ne_loss

def loss_fn(x, y):
    x = F.normalize(x, dim=-1, p=2)
    y = F.normalize(y, dim=-1, p=2)
    return 2 - 2 * (x * y).sum(dim=-1)

def train_epoch(train_loader, encoder,encoder1, critic, sobel, device,w, optimizer_e, optimizer_c, epoch,
                aug_feat_memory, org_feat_memory, log_output_file,
                global_step, file_logger, writer, args, only_train_pretext=True):
    train_data_time = utils.AverageMeter()
    train_batch_time = utils.AverageMeter()
    train_mi_loss = utils.AverageMeter()
    train_aug_loss = utils.AverageMeter()
    train_adv_e_loss = utils.AverageMeter()
    train_adv_c_loss = utils.AverageMeter()

    mse_loss = nn.MSELoss()
    kl_div_loss = nn.KLDivLoss(reduction='batchmean')
    encoder.train()
    encoder1.train()
    target_ema_updater = EMA(0.99)
    critic.train()

    tic = time.time()
    for i, data in enumerate(train_loader):
        train_data_time.update(time.time() - tic)
        x = data['image'].cuda(non_blocking=True)
        x_aug = data['augmented'].cuda(non_blocking=True)
        if not only_train_pretext:
            x_neighbor_top1 = data['neighbor_top1'].cuda(non_blocking=True)
            x_neighbor_top2 = data['neighbor_top2'].cuda(non_blocking=True)
            x_neighbor_top3 = data['neighbor_top3'].cuda(non_blocking=True)
            torchvision.utils.save_image(x_neighbor_top1,
                                         os.path.join('img', 'cluster_imgs_%03d_x.jpg' % i),
                                         nrow=10, padding=0, normalize=True, range=(-1, 1))
            torchvision.utils.save_image(x_neighbor_top2,
                                         os.path.join('img', 'cluster_imgs1_%03d_x.jpg' % i),
                                         nrow=10, padding=0, normalize=True, range=(-1, 1))
        w_batch = w[i:i+x.size(0)].cuda(non_blocking=True)
        b = x.size(0)

        if global_step % (args.skip_iter + 1) == args.skip_iter:
            zs_aug, zc_aug_logit, projection_aug = encoder(x_aug)
            zs, zc_logit, projection = encoder(x)
            zc = F.softmax(zc_logit, dim=1)
            zc_aug = F.softmax(zc_aug_logit, dim=1)
            entropy_loss = en_loss(zc) + en_loss(zc_aug)
            with torch.no_grad():
                zs_aug1, zc_aug_logit1, pro_aug= encoder1(x_aug)
                zs1, zc_logit1, pro = encoder1(x)
                zc_aug1_ = F.softmax(zc_aug_logit1, dim=1)
                zc1_ = F.softmax(zc_logit1, dim=1)

            adv_e_loss = args.beta_adv * (- torch.mean(critic(zc)) - torch.mean(critic(zc_aug)))

            # aug loss
            aug_loss = args.beta_aug * kl_div_loss(F.log_softmax(zc_aug_logit, dim=1), zc) + \
                       args.beta_aug * kl_div_loss(F.log_softmax(zc_aug_logit1, dim=1).detach(), zc) + \
                       args.beta_aug * kl_div_loss(F.log_softmax(zc_logit1, dim=1).detach(), zc_aug) + \
                       (loss_fn(projection, pro_aug.detach()) +
                        loss_fn(projection_aug, pro.detach())).mean()

            # print(aug_loss)
            if not only_train_pretext:
                zs, zc_logit, projection = encoder(x)
                zs_top1_aug, zc_top1_aug_logit, projection_top1_aug = encoder(x_neighbor_top1)
                zs_top2_aug, zc_top2_aug_logit, projection_top2_aug = encoder(x_neighbor_top2)
                zs_top3_aug, zc_top3_aug_logit, projection_top3_aug = encoder(x_neighbor_top3)

                zc = F.softmax(zc_logit, dim=1)
                zc_top1 = F.softmax(zc_top1_aug_logit,dim=1)
                zc_top2 = F.softmax(zc_top2_aug_logit,dim=1)
                zc_top3 = F.softmax(zc_top3_aug_logit,dim=1)
                # print('-----------------------')
                # print(np.argmax(zc.cpu().detach().numpy(), axis=1))
                # print(np.argmax(zc_top1.cpu().detach().numpy(), axis=1))

                #
                u_dist1 = kl_div_loss(F.log_softmax(zc_top1_aug_logit, dim=1), zc)
                u_dist2 = kl_div_loss(F.log_softmax(zc_top2_aug_logit, dim=1), zc)
                u_dist3 = kl_div_loss(F.log_softmax(zc_top3_aug_logit, dim=1), zc)
                # u_dist1 = torch.sum(torch.pow((zc - zc_top1), 2), 1).cuda()  # torch.Size([250, 20])
                # u_dist2 = torch.sum(torch.pow((zc - zc_top2), 2), 1).cuda()
                # u_dist3 = torch.sum(torch.pow((zc - zc_top3), 2), 1).cuda()
                #
                # w_loss1 = sum(torch.multiply(w_batch[:, 0], u_dist1))
                # w_loss2 = sum(torch.multiply(w_batch[:, 1], u_dist2))
                # w_loss3 = sum(torch.multiply(w_batch[:, 2], u_dist3))

                a_e_loss = 4 * (- torch.mean(critic(zc_top1)) - torch.mean(critic(zc_top2)) - torch.mean(critic(zc_top3)))
                es = 1 * (en_loss(zc_top1) + en_loss(zc_top2) + en_loss(zc_top3))
                w_loss = 4 * (u_dist1 + u_dist2 + u_dist3)
                w_loss.backward(retain_graph=True)
                es.backward(retain_graph=True)
                a_e_loss.backward(retain_graph=True)
                train_adv_c_loss.update(w_loss.item(), n=b)
            # print(aug_loss)
            # print('-----------------------------------')
            e_loss = adv_e_loss + aug_loss + 2 * entropy_loss
            optimizer_e.zero_grad()
            e_loss.backward(retain_graph=True)
            optimizer_e.step()

            update_moving_average(
                target_ema_updater, encoder1.backbone, encoder.backbone
            )

            train_adv_e_loss.update(adv_e_loss.item(), n=b)
            train_aug_loss.update(aug_loss.item(), n=b)
            #
        else:
            with torch.no_grad():
                zs, zc_logit, _ = encoder(x)
            zc = F.softmax(zc_logit, dim=1)
            zs_prior, zc_prior, _ = utils.sample_z(b, dim_zs=args.dim_zs, dim_zc=args.dim_zc, zs_std=args.zs_std)
            zc_prior = torch.tensor(zc_prior, dtype=torch.float32, device=device)
            c_real_loss = -torch.mean(critic(zc_prior))
            c_fake_loss = torch.mean(critic(zc))
            gradient_penalty = utils.calc_gradient_penalty(critic, zc_prior, zc, args.lambda_gp)
            adv_c_loss = args.beta_adv * (c_real_loss + c_fake_loss + gradient_penalty)
            optimizer_c.zero_grad()
            adv_c_loss.backward(retain_graph=True)
            optimizer_c.step()

            with torch.no_grad():
                zs, zc_logit, _ = encoder(x)
                _, zc_aug_logit, _ = encoder(x_aug)
            zc_aug = F.softmax(zc_aug_logit, dim=1)
            zc = F.softmax(zc_logit, dim=1)
            zs_prior, zc_prior, _ = utils.sample_z(b, dim_zs=args.dim_zs, dim_zc=args.dim_zc, zs_std=args.zs_std)
            zc_prior = torch.tensor(zc_prior, dtype=torch.float32, device=device)
            c_real_loss = - torch.mean(critic(zc_prior))
            c_fake_loss_aug = torch.mean(critic(zc_aug))
            c_fake_loss = torch.mean(critic(zc))
            m_loss = mse_loss(c_fake_loss_aug, c_fake_loss)
            gradient_penalty = utils.calc_gradient_penalty(critic, zc_prior, zc, args.lambda_gp)
            adv_c_loss = args.beta_adv * (c_real_loss + c_fake_loss_aug + gradient_penalty) + m_loss
            optimizer_c.zero_grad()
            adv_c_loss.backward(retain_graph=True)
            optimizer_c.step()

            if not only_train_pretext:
                with torch.no_grad():
                    zs, zc_logit, _ = encoder(x)
                    zs_top1_aug, zc_top1_aug_logit, _ = encoder(x_neighbor_top1)
                    zs_top2_aug, zc_top2_aug_logit, _ = encoder(x_neighbor_top2)
                    zs_top3_aug, zc_top3_aug_logit, _ = encoder(x_neighbor_top3)

                zc = F.softmax(zc_logit, dim=1)
                zc1 = F.softmax(zc_top1_aug_logit, dim=1)
                zc2 = F.softmax(zc_top2_aug_logit, dim=1)
                zc3 = F.softmax(zc_top3_aug_logit, dim=1)

                zs_prior, zc_prior, _ = utils.sample_z(b, dim_zs=args.dim_zs, dim_zc=args.dim_zc, zs_std=args.zs_std)
                zc_prior = torch.tensor(zc_prior, dtype=torch.float32, device=device)
                c_real_loss = 3 * (- torch.mean(critic(zc_prior)))
                c_fake_loss = torch.mean(critic(zc))
                c_fake_loss1 = torch.mean(critic(zc1))
                c_fake_loss2 = torch.mean(critic(zc2))
                c_fake_loss3 = torch.mean(critic(zc3))
                ms_loss = mse_loss(c_fake_loss, c_fake_loss1) + \
                          mse_loss(c_fake_loss, c_fake_loss2) + \
                          mse_loss(c_fake_loss, c_fake_loss3)
                c_fake_loss = c_fake_loss1 + c_fake_loss2 + c_fake_loss3
                gradient_penalty = utils.calc_gradient_penalty(critic, zc_prior, zc, args.lambda_gp)
                adv_c_loss = args.beta_adv * (c_real_loss + c_fake_loss + gradient_penalty + ms_loss)
                optimizer_c.zero_grad()
                adv_c_loss.backward(retain_graph=True)
                optimizer_c.step()
            #
            #     with torch.no_grad():
            #         zs_top2_aug, zc_top2_aug_logit, _ = encoder(x_neighbor_top2)
            #     zc = F.softmax(zc_top2_aug_logit, dim=1)
            #     zs_prior, zc_prior, _ = utils.sample_z(b, dim_zs=args.dim_zs, dim_zc=args.dim_zc, zs_std=args.zs_std)
            #     zc_prior = torch.tensor(zc_prior, dtype=torch.float32, device=device)
            #     c_real_loss = -torch.mean(critic(zc_prior))
            #     c_fake_loss = torch.mean(critic(zc))
            #     gradient_penalty = utils.calc_gradient_penalty(critic, zc_prior, zc, args.lambda_gp)
            #     adv_c_loss = args.beta_adv * (c_real_loss + c_fake_loss + gradient_penalty)
            #     optimizer_c.zero_grad()
            #     adv_c_loss.backward(retain_graph=True)
            #     optimizer_c.step()
            #
            #     with torch.no_grad():
            #         zs_top3_aug, zc_top3_aug_logit, _ = encoder(x_neighbor_top3)
            #     zc = F.softmax(zc_top3_aug_logit, dim=1)
            #     zs_prior, zc_prior, _ = utils.sample_z(b, dim_zs=args.dim_zs, dim_zc=args.dim_zc, zs_std=args.zs_std)
            #     zc_prior = torch.tensor(zc_prior, dtype=torch.float32, device=device)
            #     c_real_loss = -torch.mean(critic(zc_prior))
            #     c_fake_loss = torch.mean(critic(zc))
            #     gradient_penalty = utils.calc_gradient_penalty(critic, zc_prior, zc, args.lambda_gp)
            #     adv_c_loss = args.beta_adv * (c_real_loss + c_fake_loss + gradient_penalty)
            #     optimizer_c.zero_grad()
            #     adv_c_loss.backward(retain_graph=True)
            #     optimizer_c.step()
        if not only_train_pretext:
            if i % 100 == 0 and i != 0:
                z1 = np.argmax(zc[:10].cpu().detach().numpy(), axis=1)
                z2 = np.argmax(zc_aug[:10].cpu().detach().numpy(), axis=1)

                z3 = np.argmax(zc_top1[:10].cpu().detach().numpy(), axis=1)
                z4 = np.argmax(zc_top2[:10].cpu().detach().numpy(), axis=1)
                z5 = np.argmax(zc_top3[:10].cpu().detach().numpy(), axis=1)
                print(z1,z3,z4)
                print(z2,z5)
                print('----------------------------------------------')
        # with torch.no_grad():
        #     zs, zc_logit, projection = encoder(x)
        #     zc = F.softmax(zc_logit, dim=1)
        #     org_feat_memory.push(zc.clone().detach(), data['meta']['index'])
        train_batch_time.update(time.time() - tic)

        global_step += 1
        tic = time.time()

    file_logger.info('Epoch {0} (train):\t'
                     'data_time: {data_time.sum:.2f}s\t'
                     'batch_time: {batch_time.sum:.2f}s\t'
                     'mi_loss: {mi_loss.avg:.4f}\t'
                     'aug_loss: {aug_loss.avg:.4f}\t'
                     'adv_e_loss: {adv_e_loss.avg:.4f}\t'
                     'adv_c_loss: {adv_c_loss.avg:.4f}\t'.format(
        epoch, data_time=train_data_time, batch_time=train_batch_time, mi_loss=train_mi_loss,
        aug_loss=train_aug_loss, adv_e_loss=train_adv_e_loss, adv_c_loss=train_adv_c_loss))

    writer.add_scalars('mi_loss', {'train': train_mi_loss.avg}, epoch)
    writer.add_scalars('aug_loss', {'train': train_aug_loss.avg}, epoch)
    writer.add_scalars('adv_e_loss', {'train': train_adv_e_loss.avg}, epoch)
    writer.add_scalars('adv_c_loss', {'train': train_adv_c_loss.avg}, epoch)

    return global_step
from sklearn.neighbors import NearestNeighbors

def eval_epoch(eval_loader, model_byol, critic, sobel, device, epoch, checkpoint_path, file_logger, writer,
               best_metrics, args):
    max_acc, max_nmi, max_ari = best_metrics

    eval_data_time = utils.AverageMeter()
    eval_batch_time = utils.AverageMeter()

    imgs = list()
    zs = list()
    zc = list()
    y_true = list()

    model_byol.eval()

    tic = time.time()
    with torch.no_grad():
        for i,data in eval_loader:
            eval_data_time.update(time.time() - tic)
            x, y_true_ = data
            x = x.to(device, non_blocking=True)
            if args.img_type == 'sobel':
                x = sobel(x)

            aug_loss, online_representation_one, online_representation_two, zc_, zc_aug_ = model_byol(x, x, True)

            imgs.append(x.cpu().numpy())
            zs.append(online_representation_one.cpu().numpy())
            zc.append((zc_ + zc_aug_).cpu().numpy())
            y_true.append(y_true_.cpu().numpy())

            eval_batch_time.update(time.time() - tic)

            tic = time.time()
    imgs = np.concatenate(imgs, axis=0)
    zs = np.concatenate(zs, axis=0)
    zc = np.concatenate(zc, axis=0)
    y_true = np.concatenate(y_true, axis=0)

    # calculate metrics
    y_pred = np.argmax(zc, axis=1)

    num_classes = zc.shape[1]
    match = utils.hungarian_match(y_pred, y_true, num_classes)
    y_pred = utils.convert_cluster_assignment_to_ground_truth(y_pred, match)

    acc = metrics.accuracy(y_pred, y_true)
    nmi = metrics.nmi(y_pred, y_true)
    ari = metrics.ari(y_pred, y_true)

    max_acc = max(max_acc, acc)
    max_nmi = max(max_nmi, nmi)
    max_ari = max(max_ari, ari)

    tic = time.time()
    # save some images
    if epoch == 0:
        real_img_idx = np.random.choice(np.arange(len(eval_loader.dataset)), 100, replace=False)
        imgs_ = torch.tensor(imgs[real_img_idx], dtype=torch.float32)
        if args.img_type == 'sobel':
            torchvision.utils.save_image(imgs_[:, :1], os.path.join(checkpoint_path, 'img', 'real_x.jpg'), nrow=10,
                                         padding=0, normalize=True, range=(-1, 1))
            torchvision.utils.save_image(imgs_[:, 1:], os.path.join(checkpoint_path, 'img', 'real_y.jpg'), nrow=10,
                                         padding=0, normalize=True, range=(-1, 1))
        else:
            torchvision.utils.save_image(imgs_, os.path.join(checkpoint_path, 'img', 'real.jpg'), nrow=10,
                                         padding=0, normalize=True, range=(-1, 1))
    if epoch == 0 or (epoch + 1) % args.save_per_epochs == 0:
        # save models
        utils.save_model(model_byol, os.path.join(checkpoint_path, 'model', 'model_byol_%03d.tar' % epoch))
        utils.save_model(critic, os.path.join(checkpoint_path, 'model', 'critic_%03d.tar' % epoch))
        # utils.save_model(encoder1, os.path.join(checkpoint_path, 'model', 'encoder1_%03d.tar' % epoch))

        # save top 10 images for each cluster
        cluster_imgs = list()
        for cls in range(num_classes):
            cls_score = zc[:, cls]
            idxs = np.argsort(cls_score)[::-1][:10]
            cluster_imgs.append(imgs[idxs])
        cluster_imgs = np.concatenate(cluster_imgs, axis=0)
        cluster_imgs = torch.tensor(cluster_imgs, dtype=torch.float32)
        if args.img_type == 'sobel':
            torchvision.utils.save_image(cluster_imgs[:, :1],
                                         os.path.join(checkpoint_path, 'img', 'cluster_imgs_%03d_x.jpg' % epoch),
                                         nrow=10, padding=0, normalize=True, range=(-1, 1))
            torchvision.utils.save_image(cluster_imgs[:, 1:],
                                         os.path.join(checkpoint_path, 'img', 'cluster_imgs_%03d_y.jpg' % epoch),
                                         nrow=10, padding=0, normalize=True, range=(-1, 1))
        else:
            torchvision.utils.save_image(cluster_imgs,
                                         os.path.join(checkpoint_path, 'img', 'cluster_imgs_%03d.jpg' % epoch), nrow=10,
                                         padding=0, normalize=True, range=(-1, 1))

        # save tsne image
        idxs = np.random.choice(np.arange(len(eval_loader.dataset)), 1000, replace=False)
        z = np.concatenate([zs[idxs], zc[idxs]], axis=1)
        visualization.tsne(z, y=y_true[idxs], show_legend=False,
                           save_path=os.path.join(checkpoint_path, 'img', 'tsne_%03d.jpg' % epoch), show_fig=False)
    eval_save_time = time.time() - tic

    file_logger.info('Epoch {0} (eval):\t'
                     'data_time: {data_time.sum:.2f}s\t'
                     'batch_time: {batch_time.sum:.2f}s\t'
                     'save_time: {save_time:.2f}s\t'
                     'acc: {acc:.2f}% ({max_acc:.2f}%)\t'
                     'nmi: {nmi:.4f} ({max_nmi:.4f})\t'
                     'ari: {ari:.4f} ({max_ari:.4f})\t'.format(epoch,
                                                               data_time=eval_data_time, batch_time=eval_batch_time,
                                                               save_time=eval_save_time,
                                                               acc=acc, max_acc=max_acc, nmi=nmi, max_nmi=max_nmi,
                                                               ari=ari, max_ari=max_ari))
    writer.add_scalars('acc', {'val': acc}, epoch)
    writer.add_scalars('nmi', {'val': nmi}, epoch)
    writer.add_scalars('ari', {'val': ari}, epoch)

    return max_acc, max_nmi, max_ari


if __name__ == '__main__':
    _main()
